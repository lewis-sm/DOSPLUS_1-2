
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cmdio.h"

cmd_desc dosplus_sys, bdos_cmd, xios_cmd, ccp_cmd, dos_cmd;

static unsigned sys_base = 0x60;
static unsigned ram_top  = 0xA000;

void dump_cmd(char *caption, cmd_desc *cmd)
{
	printf("%s CS: base=%04x length=%05lx\n",
		caption, cmd->cs_base, cmd->cs_len);
	printf("%s DS: base=%04x length=%05lx\n",
		caption, cmd->ds_base, cmd->ds_len);
}


/* Fix up buffer pointers by:
 * 1. Finding the DPH for drive A:
 * 2. Finding the buffer control block list from the DPH.
 * 3. Walking the list, converting the offset of each buffer into
 *   a segment. */
void fixup_buffers()
{
	unsigned short dph_a   = peekw_cmd(&dosplus_sys, DGROUP, 0xF08);
	unsigned short databcb = peekw_cmd(&dosplus_sys, DGROUP, dph_a + 0x10);
	unsigned short bcb     = peekw_cmd(&dosplus_sys, DGROUP, databcb);
	unsigned short buf;

	printf("Data buffer fixups:\n");
	while (bcb)	
	{
		buf = peekw_cmd(&dosplus_sys, DGROUP, bcb + 0x0A);
		printf("Offset %04x -> ", buf);
		/* Offsets can't be below 0xF00, so treat those as 
		 * absolute segments */
		if (buf >= 0xF00)
		{	
			buf = ((buf + 15) / 16) + dosplus_sys.ds_base;
		}
		printf("Segment %04x\n", buf);
		pokew_cmd(&dosplus_sys, DGROUP, bcb + 0x0A, buf);	
		bcb = peekw_cmd(&dosplus_sys, DGROUP, bcb + 0x0C);
	}
}



int main(int argc, char **argv)
{
	char *boo;
	long o = 0;
	long xios_cs, dos_cs, dos_ds, ccp_cs, ccp_ds;
	dword sysfile_top;
	/* Load the component parts */
	unsigned sb = sys_base;
	unsigned st = ram_top;

	if (argc > 1 && sscanf(argv[1], "0x%x", &sb) == 1)
	{
		sys_base = sb;
	}
	if (argc > 2 && sscanf(argv[2], "0x%x", &st) == 1)
	{
		ram_top = st;
	}

	boo = load_cmd("bdos.cmd", &bdos_cmd);
	if (boo) { fprintf(stderr, "bdos.cmd: %s\n", boo); return 1; }	
	boo = load_cmd("xios.cmd", &xios_cmd);
	if (boo) { fprintf(stderr, "xios.cmd: %s\n", boo); return 1; }	
	boo = load_cmd("ccp.cmd", &ccp_cmd);
	if (boo) { fprintf(stderr, "ccp.cmd: %s\n", boo); return 1; }	
	load_cmd("dos.cmd", &dos_cmd);
	printf("System base at %04x:0000\n", sys_base);
	printf("End of RAM  at %04x:0000\n", ram_top);

	/* Work out segment sizes */
	dosplus_sys.cs_max = 
	dosplus_sys.cs_len = bdos_cmd.cs_len + xios_cmd.cs_len + 
			     ccp_cmd.cs_len + ccp_cmd.ds_len + 
			     dos_cmd.cs_len + dos_cmd.ds_len;
	dosplus_sys.cs_base = sys_base;
	dosplus_sys.ds_len = xios_cmd.ds_len;
	dosplus_sys.ds_max = xios_cmd.ds_max;
	dosplus_sys.ds_base = sys_base + (dosplus_sys.cs_len >> 4);

	boo = alloc_cmd(&dosplus_sys, dosplus_sys.cs_len, dosplus_sys.ds_len);
	if (boo) { fprintf(stderr, "%s", boo); return 1; }	

	printf("Code segment at %04x:0000 length 0x%05lx\n", 
			dosplus_sys.cs_base, 
			dosplus_sys.cs_len);
	printf("Data segment at %04x:0000 length 0x%05lx\n", 
			dosplus_sys.ds_base, 
			dosplus_sys.ds_len);

	/* OK. Now copy the modules into the SYS file */

	cmdcpy(&dosplus_sys, CGROUP, o, &bdos_cmd, CGROUP, 0, bdos_cmd.cs_len);
	o += bdos_cmd.cs_len;
	xios_cs = o;
	cmdcpy(&dosplus_sys, CGROUP, o, &xios_cmd, CGROUP, 0, xios_cmd.cs_len);
	o += xios_cmd.cs_len;
	if (dos_cmd.cs_len)
	{
		dos_cs = o;
		cmdcpy(&dosplus_sys, CGROUP, o, 
			&dos_cmd, CGROUP, 0, dos_cmd.cs_len);
		o += dos_cmd.cs_len;
	}
	ccp_cs = o;
	cmdcpy(&dosplus_sys, CGROUP, o, &ccp_cmd, CGROUP, 0, ccp_cmd.cs_len);
	o += ccp_cmd.cs_len;
	ccp_ds = o;
	cmdcpy(&dosplus_sys, CGROUP, o, &ccp_cmd, DGROUP, 0, ccp_cmd.ds_len);
	o += ccp_cmd.ds_len;
	if (dos_cmd.ds_len)
	{
		dos_ds = o;
		cmdcpy(&dosplus_sys, CGROUP, o, 
			&dos_cmd, DGROUP, 0, dos_cmd.ds_len);
		o += dos_cmd.ds_len;
	}
	/* Initialise the data segment from the XIOS dseg */
	cmdcpy(&dosplus_sys, DGROUP, 0, &xios_cmd, DGROUP, 0, xios_cmd.ds_len);
	/* Then copy the (shorter) BDOS dseg over it */
	cmdcpy(&dosplus_sys, DGROUP, 0, &bdos_cmd, DGROUP, 0, bdos_cmd.ds_len);

	/* Set up the pointers to modules correctly */
	pokew_cmd(&dosplus_sys, CGROUP, 6, dosplus_sys.ds_base);
	pokew_cmd(&dosplus_sys, CGROUP, xios_cs + 6, dosplus_sys.ds_base);
	if (dos_cmd.ds_len)
	{
		pokew_cmd(&dosplus_sys, CGROUP, dos_cs + 6, dosplus_sys.ds_base);
		pokew_cmd(&dosplus_sys, CGROUP, dos_cs + 8, (dos_ds >> 4) + sys_base); 
	}
	pokew_cmd(&dosplus_sys, CGROUP, ccp_ds    , ccp_cmd.cs_len);
	pokew_cmd(&dosplus_sys, CGROUP, ccp_ds + 3, (ccp_cs >> 4) + sys_base);
	pokew_cmd(&dosplus_sys, CGROUP, ccp_ds + 6, ccp_cmd.ds_len);
	pokew_cmd(&dosplus_sys, CGROUP, ccp_ds + 9, (ccp_ds >> 4) + sys_base);
	pokew_cmd(&dosplus_sys, DGROUP, 0x2A, (xios_cs >> 4) + sys_base);
	pokew_cmd(&dosplus_sys, DGROUP, 0x2E, (xios_cs >> 4) + sys_base);
	if (dos_cmd.ds_len)
		pokew_cmd(&dosplus_sys, DGROUP, 0x42, (dos_cs >> 4) + sys_base);
	else	pokew_cmd(&dosplus_sys, DGROUP, 0x42, 0);
	pokew_cmd(&dosplus_sys, DGROUP, 0x44, (ccp_ds >> 4) + sys_base);
	sysfile_top = (dosplus_sys.cs_max + 
                       dosplus_sys.ds_max + 16L * sys_base) >> 4; 
	pokew_cmd(&dosplus_sys, DGROUP, 0x48,   sysfile_top);

	/* Fix up TPA address and size */
	if (sys_base == 0x60)
	{
/* Assume if sys_base == 0x60 that the first entry in the memory table 
 * comes immediately above the system (ie, PC1512; Master XIOS 1.03) */
		pokew_cmd(&dosplus_sys, DGROUP, 0x0F56, sysfile_top);
		pokew_cmd(&dosplus_sys, DGROUP, 0x0F58, ram_top - sysfile_top);
	}
	else
	{
/* Otherwise assume the first entry comes below the system, and the 
 * second covers memory above the system (ie, BBC Master XIOS 1.01) */
		pokew_cmd(&dosplus_sys, DGROUP, 0x0F5E, ram_top - sysfile_top);
	}
	/* Fix up the data buffers, which are stored as segments */
	fixup_buffers();

	/* SYS file has been generated. Write it. */

	dump_cmd("BDOS ", &bdos_cmd);
	dump_cmd("XIOS ", &xios_cmd);
	if (dos_cmd.cs_len) dump_cmd("DOS  ", &dos_cmd);
	dump_cmd("CCP  ", &ccp_cmd);
	dump_cmd("SYS  ", &dosplus_sys);

	/* Now start writing the stuff out */
	boo           = save_cmd("new.sys", &dosplus_sys, 1);
	if (boo) fprintf(stderr, "new.sys: %s\n", boo);
	free_cmd(&dosplus_sys); 
	free_cmd(&bdos_cmd); 
	free_cmd(&xios_cmd);
	free_cmd(&ccp_cmd);
	free_cmd(&dos_cmd);
	return 0;
}


