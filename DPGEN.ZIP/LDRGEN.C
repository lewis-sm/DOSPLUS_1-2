#include <stdio.h>
#include <stdlib.h>
#include <string.h>

FILE *fpfixldr, *fploader;
typedef unsigned char byte;
byte *fixfile;
long fixlen;

#ifndef SEEK_SET
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
#endif

int main(int argc, char **argv)
{
	long a;

	if (argc < 3)
	{
		fprintf(stderr, "Syntax: LDRGEN fixldr.com loader.bin\n");
		return 1;
	}	
	fpfixldr = fopen(argv[1], "rb");
	if (fpfixldr == NULL)
	{
		perror(argv[1]);
		return 1;
	}
	fploader = fopen(argv[2], "rb");
	if (fploader == NULL)
	{
		perror(argv[2]);
		return 1;
	}
	fseek(fpfixldr, 0, SEEK_END);
	fixfile = malloc(fixlen = ftell(fpfixldr));
	if (!fixfile)
	{
		fprintf(stderr, "Error: Could not allocate %ld bytes\n",
				fixlen);
		return 1;
	}	
	fseek(fpfixldr, 0, SEEK_SET);
	fread(fixfile, 1, fixlen, fpfixldr);
	printf("Loaded %s\n", argv[1]);

/* Search for the "New Loader=>" signature in FIXLDR */

	for (a = 0; a < fixlen - 16; a++)
	{
		if (!memcmp(fixfile + a, "   New loader =>", 16)) break;
	}
	if (a < fixlen - 16)
	{
		printf("Found \"New loader=>\" signature.\n");
		if (fread(fixfile + a + 16, 1, 0xA00, fploader) < 0xA00)
		{
			fprintf(stderr, "Warning: Short loader file\n");
		}

		fclose(fpfixldr);
		printf("Writing %s...", argv[1]);
		fpfixldr = fopen(argv[1], "wb");
		fwrite(fixfile, 1, 0xE00, fpfixldr);
		printf("done.\n");
	}
	else fprintf(stderr, "Error: \"New loader =>\" signature not found.\n");
	
	fclose(fploader);
	fclose(fpfixldr);
	return 0;
}
