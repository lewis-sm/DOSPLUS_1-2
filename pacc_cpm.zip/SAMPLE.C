
/* This is a simple test of Pacific as a DOS -> CP/M-86 cross compiler. */

#include <bdos.h>

int main(int argc, char **argv)
{
	char *args = (char *)0x80;

	bdos(9, (unsigned short)"CP/M-86 sample\r\nCommand tail:$");
	argc = *args++;
	while (argc)
	{
		bdos(2, *args++);
		--argc;
	}
	bdos(2,0x0D);
	bdos(2,0x0A);

	return 0;
}
