
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cmdio.h"

#define GROUPSPLIT 0xF000L

static byte zeroes[16];

void zero_cmd(cmd_desc *cmdfile)
{
#ifdef __MSDOS__
	cmdfile->cs00    = cmdfile->ds00 = NULL;
	cmdfile->cs60    = cmdfile->ds60 = NULL;
#else
	cmdfile->cs      = cmdfile->ds = NULL;
#endif
	cmdfile->cs_base = cmdfile->ds_base = 0;
	cmdfile->cs_len  = cmdfile->ds_len = 0;
	cmdfile->cs_max  = cmdfile->ds_max = 0;
}

void free_cmd (cmd_desc *cmdfile)
{
#ifdef __MSDOS__
	if (cmdfile->ds60) free(cmdfile->ds60);
	if (cmdfile->cs60) free(cmdfile->cs60);
	if (cmdfile->ds00) free(cmdfile->ds00);
	if (cmdfile->cs00) free(cmdfile->cs00);
#else
	if (cmdfile->ds)   free(cmdfile->ds);
	if (cmdfile->cs)   free(cmdfile->cs);
#endif
	zero_cmd(cmdfile);	
}


static word peekw(byte *base, word a)
{
        return base[a] | (((word)base[a+1]) << 8);
}

static void pokew(byte *base, word a, word v)
{
	base[a  ] = (v) & 0xFF;
	base[a+1] = (v >> 8) & 0xFF;
}


byte peek_cmd(cmd_desc *cmd, GROUP group, dword offset)
{
#ifdef __MSDOS__
	if (offset < GROUPSPLIT)  
		return (group ? cmd->ds00 : cmd->cs00)[offset];
	else	return (group ? cmd->ds60 : cmd->cs60)[offset - GROUPSPLIT];
#else
	return (group ? cmd->ds : cmd->cs)[offset];
#endif
}

void poke_cmd(cmd_desc *cmd, GROUP group, dword offset, byte value)
{
#ifdef __MSDOS__
	if (offset < GROUPSPLIT)  
		(group ? cmd->ds00 : cmd->cs00)[offset] = value;
	else	(group ? cmd->ds60 : cmd->cs60)[offset - GROUPSPLIT] = value;
#else
	(group ? cmd->ds : cmd->cs)[offset] = value;
#endif
}



char *alloc_cmd(cmd_desc *cmdfile, long cs_len, long ds_len)
{
	if (!cs_len) return "Code group length is 0.";
	if (!ds_len) return "Data group length is 0.";

#ifdef __MSDOS__
	if (cs_len > 2 * GROUPSPLIT)
	{
		return "Code group length exceeds 120k";
	}
	if (ds_len > 2 * GROUPSPLIT)
	{
		return "Data group length exceeds 120k";
	}

	if (cs_len > GROUPSPLIT)
	{
		cmdfile->cs00 = malloc(GROUPSPLIT);
		cmdfile->cs60 = malloc(cs_len - GROUPSPLIT);
		if (!cmdfile->cs60)
		{
			free_cmd(cmdfile); 
			return "Out of memory.";
		}
	}
	else
	{
		cmdfile->cs00    = malloc(cs_len);
	}
	if (ds_len > GROUPSPLIT)
	{
		cmdfile->ds00 = malloc(GROUPSPLIT);
		cmdfile->ds60 = malloc(ds_len - GROUPSPLIT);
		if (!cmdfile->ds60)
		{
			free_cmd(cmdfile); 
			return "Out of memory.";
		}
	}
	else
	{
		cmdfile->ds00    = malloc(ds_len);
	}
	if (!cmdfile->ds00 || !cmdfile->cs00) 
	{
		free_cmd(cmdfile); 
		return "Out of memory.";
	}
#else	/* __MSDOS__ */
	cmdfile->cs      = malloc(cs_len);
	cmdfile->ds      = malloc(ds_len);
	if (!cmdfile->ds || !cmdfile->cs) 
	{
		free_cmd(cmdfile); 
		return "Out of memory.";
	}
#endif

	return NULL;
}

char *load_cmd(char *filename, cmd_desc *cmdfile)
{
	FILE *fp;
	char *boo;
	byte cmd_header[128];
	dword offset;

	fp = fopen(filename, "rb");
	if (!fp) return "Failed to open file.";

	if (fread(cmd_header, 1, sizeof(cmd_header), fp) < (int)sizeof(cmd_header)) 	
	{
		fclose(fp);
		return "Too short to be a CMD file.";
	}
	cmdfile->cs_len  = peekw(cmd_header, 1);
	cmdfile->cs_base = peekw(cmd_header, 3);
	cmdfile->cs_max  = peekw(cmd_header, 5);
	cmdfile->ds_len  = peekw(cmd_header, 10);
	cmdfile->ds_base = peekw(cmd_header, 12);
	cmdfile->ds_max  = peekw(cmd_header, 14);
	
	if (!cmdfile->cs_len || !cmdfile->ds_len) 
	{
		fclose(fp);
		return "Not a 2-segment CMD file";
	}
	boo = alloc_cmd(cmdfile, 16L * cmdfile->cs_max, 16L * cmdfile->ds_max);
	if (boo)
	{
		fclose(fp);
		return boo;
	}
	for (offset = 0; offset < 16 * cmdfile->cs_len; offset++)
	{
		int c = fgetc(fp);
		if (c == EOF)
		{
			fclose(fp);
			free_cmd(cmdfile);
			return "Failed to load code group.";
		}
		poke_cmd(cmdfile, CGROUP, offset, c);
	}
	for (offset = 0; offset < 16 * cmdfile->ds_len; offset++)
	{
		int c = fgetc(fp);
		if (c == EOF)
		{
			fclose(fp);
			free_cmd(cmdfile);
			return "Failed to load data group.";
		}
		poke_cmd(cmdfile, DGROUP, offset, c);
	}
	fclose(fp);
	cmdfile->cs_len *= 16L;
	cmdfile->ds_len *= 16L;
	cmdfile->cs_max *= 16L;
	cmdfile->ds_max *= 16L;
	return NULL;
}


void cmdcpy(cmd_desc *dest, GROUP destgroup, long destoffset,
	    cmd_desc *src, GROUP srcgroup, long srcoffset,
	    long count)
{
	while (count)
	{
		poke_cmd(dest, destgroup, destoffset,
			peek_cmd(src, srcgroup, srcoffset));
		++destoffset;
		++srcoffset;
		--count;
	}
}


word peekw_cmd(cmd_desc *cmd, GROUP group, dword offset)
{
	return (((word)peek_cmd(cmd, group, offset + 1)) << 8)  |
		       peek_cmd(cmd, group, offset);
}

void pokew_cmd(cmd_desc *cmd, GROUP group, dword offset, word v)
{
	poke_cmd(cmd, group, offset,     v & 0xFF);
	poke_cmd(cmd, group, offset + 1, (v >> 8) & 0xFF);
}


char *save_cmd(char *cmdname, cmd_desc *cmdfile, int absolute)
{
	FILE *fp;
	word csparas, cmparas;
	word dsparas, dmparas;
	byte header[128];
	dword offset;
	int c;

	csparas = cmdfile->cs_len >> 4;
	dsparas = cmdfile->ds_len >> 4;
	cmparas = cmdfile->cs_max >> 4;
	dmparas = cmdfile->ds_max >> 4;

	memset(header, 0, sizeof(header));
	header[0] = 1;	/* Code segment */
	pokew(header, 1, csparas);
	if (absolute) pokew(header, 3, cmdfile->cs_base);
	pokew(header, 5, cmparas);
	header[9] = 2;	/* Data segment */
	pokew(header, 10, dsparas);
	if (absolute) pokew(header, 12, cmdfile->ds_base);
	pokew(header, 14, dmparas);

	fp = fopen(cmdname, "wb");
	if (!fp) 
	{
		return "Cannot open file to write.";
	}
	if (fwrite(header, 1, 128, fp) < 128)
	{
		fclose(fp);
		return "Error writing header to CMD file";
	}
	for (offset = 0; offset < cmdfile->cs_len; offset++)
	{
		c = peek_cmd(cmdfile, CGROUP, offset);
		if (fputc(c, fp) == EOF)
		{
			fclose(fp);
			return "Error writing code group to CMD file";
		}
	}
	for (offset = 0; offset < cmdfile->ds_len; offset++)
	{
		c = peek_cmd(cmdfile, DGROUP, offset);
		if (fputc(c, fp) == EOF)
		{
			fclose(fp);
			return "Error writing data group to CMD file";
		}
	}

	/* Pack out to a multiple of 128 bytes */
	while ((csparas + dsparas) & 7)
	{
		fwrite(zeroes, 1, 16, fp);
		++dsparas;
	}	
	fclose(fp);
	return NULL;
}

