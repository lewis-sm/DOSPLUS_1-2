#include	<stdio.h>

/* Infamous "hello world" program */

main()
{
	printf("Hello, world\n");
}
