
#include <stdio.h>
#include <stdlib.h>
#include <dos.h>

FILE *bootsec;
unsigned char sector[512];

int drive;

void bless_disc(void)
{
	union REGS rg;
	struct SREGS sr;

	rg.x.ax = 0x0301;
	rg.x.bx = FP_OFF(sector);
	rg.x.cx = 1;		/* Cylinder 0, sector 1 */
	rg.x.dx = drive - 1;	/* Drive & head */
	sr.es   = FP_SEG(sector);
	int86x(0x13, &rg, &rg, &sr);
	if (rg.h.al != 0 && rg.x.cflag)
	{
		fprintf(stderr, "Write sector failed, error=%d\n",
			rg.h.al);
	}
}

int main(int argc, char **argv)
{
	if (argc < 3)
	{
		fprintf(stderr, "Syntax is: BLESS x: boot.sec");
		return 1;
	}
	drive = argv[1][0] & 0x1F;
	if (drive == 0 || drive > 4)
	{
		fprintf(stderr, "Syntax is: BLESS x: boot.sec");
		return 1;
	}

	fprintf(stderr, "Opening %s\n", argv[2]);
	bootsec = fopen(argv[2], "rb");
	if (!bootsec)
	{
		perror(argv[2]);
		return 1;
	}
	if (fread(sector, 1, 512, bootsec) < 512)
	{
		perror(argv[1]);
		fclose(bootsec);
		return 1;
	}

	fprintf(stderr, "Writing data\n");
	fclose(bootsec);
	bless_disc();
	return 0;
}
