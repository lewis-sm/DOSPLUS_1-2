
#include <stdio.h>
#include <stdlib.h>

FILE *cmdfile, *bootsec;
unsigned char sector[512];

int main(int argc, char **argv)
{
	if (argc < 3)
	{
		fprintf(stderr, "Syntax is: CMD2SEC file.cmd file.sec");
		return 1;
	}
	fprintf(stderr, "Opening %s\n", argv[1]);
	cmdfile = fopen(argv[1], "rb");
	if (!cmdfile)
	{
		perror(argv[1]);
		return 1;
	}
	fprintf(stderr, "Opening %s\n", argv[2]);
	bootsec = fopen(argv[2], "wb");
	if (!bootsec)
	{
		perror(argv[2]);
		fclose(cmdfile);
		return 1;
	}
	fprintf(stderr, "Seeking to data\n");
	fseek(cmdfile, 0x7C80, 0);
	fprintf(stderr, "Reading data\n");
	if (fread(sector, 1, 512, cmdfile) < 512)
	{
		perror(argv[1]);
		fclose(cmdfile);
		fclose(bootsec);
		remove(argv[2]);
		return 1;
	}

	fprintf(stderr, "Writing data\n");
	if (fwrite(sector, 1, 512, bootsec) < 512)
	{
		perror(argv[2]);
		fclose(cmdfile);
		fclose(bootsec);
		remove(argv[2]);
		return 1;
	}
	fclose(cmdfile);
	fclose(bootsec);
	return 0;
}
