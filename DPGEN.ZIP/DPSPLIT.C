
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cmdio.h"

cmd_desc dosplus_sys, bdos_cmd, xios_cmd, ccp_cmd, dos_cmd;

void dump_cmd(char *caption, cmd_desc *cmd)
{
	printf("%s CS: base=%04x length=%05lx\n",
		caption, cmd->cs_base, cmd->cs_len);
	printf("%s DS: base=%04x length=%05lx\n",
		caption, cmd->ds_base, cmd->ds_len);
}

/* Reverse the fixup that DPGEN does to the XIOS, so that DPGEN 
 * followed by DPSPLIT (or vice versa) gives back the same file. */
void unfixup_buffers()
{
        word dph_a   = peekw_cmd(&xios_cmd, DGROUP, 0xF08);
        word databcb = peekw_cmd(&xios_cmd, DGROUP, dph_a + 0x10);
        word bcb     = peekw_cmd(&xios_cmd, DGROUP, databcb);
        word buf;

        printf("Data buffer fixups:\n");
        while (bcb)     
        {
                buf = peekw_cmd(&xios_cmd, DGROUP, bcb + 0x0A);
                printf("Segment %04x -> ", buf);    
		/* Addresses below the XIOS base stay unchanged */
		if (buf > xios_cmd.ds_base)
		{
                	buf = (buf - xios_cmd.ds_base) * 16;
		}
                printf("Offset %04x\n", buf);
                pokew_cmd(&xios_cmd, DGROUP, bcb + 0x0A, buf); 
                bcb = peekw_cmd(&xios_cmd, DGROUP, bcb + 0x0C);
        }
}

int main(int argc, char **argv)
{
	char *boo;
	/* Open DOSPLUS.SYS */
	dword offset_ccp;
	dword offset_dos;
	int n;

	if (argc < 2)	
	{
		fprintf(stderr, "Syntax: dpsplit dosplus.sys\n"); 
		exit(1);
	}
	boo = load_cmd(argv[1], &dosplus_sys);
	if (boo) { fprintf(stderr, "%s: %s\n", argv[1], boo); return 1; }	

	printf("Code segment at %04x:0000 length 0x%05lx\n", 
			dosplus_sys.cs_base, 
			dosplus_sys.cs_max);
	printf("Data segment at %04x:0000 length 0x%05lx\n", 
			dosplus_sys.ds_base, 
			dosplus_sys.ds_max);

	/* OK. The whole SYS file has been loaded. Now we have to work 
	 * out where its constituent modules are. */

	xios_cmd.cs_base = peekw_cmd(&dosplus_sys, DGROUP, 0x2A);
	xios_cmd.ds_base = dosplus_sys.ds_base;
	xios_cmd.ds_len  = dosplus_sys.ds_len;
	xios_cmd.ds_max  = dosplus_sys.ds_max;
	dos_cmd.cs_base  = peekw_cmd(&dosplus_sys, DGROUP, 0x42);
	ccp_cmd.ds_base  = peekw_cmd(&dosplus_sys, DGROUP, 0x44);

	/* The CCP is stored as a loaded .CMD file; so its data segment
	 * holds the addresses of itself and of its code segment */
	offset_ccp = 16L * (ccp_cmd.ds_base - dosplus_sys.cs_base);

	ccp_cmd.cs_base  = peekw_cmd( &dosplus_sys, CGROUP, offset_ccp + 3);
	ccp_cmd.cs_max   =
	ccp_cmd.cs_len   = peekw_cmd( &dosplus_sys, CGROUP, offset_ccp + 0);
	ccp_cmd.ds_max   =
	ccp_cmd.ds_len   = peekw_cmd( &dosplus_sys, CGROUP, offset_ccp + 6);


	/* The address of the DOS dseg is at dos_cseg:8 */
	if (dos_cmd.cs_base) 
	{
		offset_dos = 16L * (dos_cmd.cs_base - dosplus_sys.cs_base);

		dos_cmd.ds_base = peekw_cmd( &dosplus_sys, CGROUP,	
						offset_dos + 8);
		dos_cmd.cs_len = dos_cmd.cs_max = 16L * (ccp_cmd.cs_base - dos_cmd.cs_base);
		dos_cmd.ds_len = dos_cmd.ds_max = 16L * (dosplus_sys.ds_base - dos_cmd.ds_base);
		xios_cmd.cs_len = xios_cmd.cs_max = 16L * (dos_cmd.cs_base - xios_cmd.cs_base);
	}
	else 
	{
		xios_cmd.cs_len = xios_cmd.cs_max = 16L * (ccp_cmd.cs_base - xios_cmd.cs_base);
	}
	bdos_cmd.cs_base = dosplus_sys.cs_base;
	bdos_cmd.cs_len  = bdos_cmd.cs_max = 16L * (xios_cmd.cs_base - dosplus_sys.cs_base);
	bdos_cmd.ds_base = dosplus_sys.ds_base;
	bdos_cmd.ds_len  = bdos_cmd.ds_max = 0x0F00;	/* hardcoded, ugh */

	boo = alloc_cmd(&bdos_cmd, bdos_cmd.cs_len, bdos_cmd.ds_len);
	if (boo) { fprintf(stderr, "BDOS: %s\n", boo); return 1; }	
	cmdcpy(&bdos_cmd, CGROUP, 0, &dosplus_sys, CGROUP, 0, bdos_cmd.cs_len);
	cmdcpy(&bdos_cmd, DGROUP, 0, &dosplus_sys, DGROUP, 0, bdos_cmd.ds_len);

	boo = alloc_cmd(&xios_cmd, xios_cmd.cs_len, xios_cmd.ds_len);
	if (boo) { fprintf(stderr, "XIOS: %s\n", boo); return 1; }	
	cmdcpy(&xios_cmd, CGROUP, 0, &dosplus_sys, CGROUP, 
		16L * (xios_cmd.cs_base - dosplus_sys.cs_base), 
		xios_cmd.cs_len);
	cmdcpy(&xios_cmd, DGROUP, 0, &dosplus_sys, DGROUP, 0, xios_cmd.ds_len);

	boo = alloc_cmd(&ccp_cmd, ccp_cmd.cs_len, ccp_cmd.ds_len);
	if (boo) { fprintf(stderr, "CCP: %s\n", boo); return 1; }	
	cmdcpy(&ccp_cmd, CGROUP, 0, &dosplus_sys, CGROUP, 
		16L * (ccp_cmd.cs_base - dosplus_sys.cs_base), 
		ccp_cmd.cs_len);
	cmdcpy(&ccp_cmd, DGROUP, 0, &dosplus_sys, CGROUP, 
		16L * (ccp_cmd.ds_base - dosplus_sys.cs_base), 
		ccp_cmd.ds_len);

	if (dos_cmd.cs_len)
	{
		boo = alloc_cmd(&dos_cmd, dos_cmd.cs_len, dos_cmd.ds_len);
		if (boo) { fprintf(stderr, "DOS: %s\n", boo); return 1; }	
		cmdcpy(&dos_cmd, CGROUP, 0, &dosplus_sys, CGROUP, 
			16L * (dos_cmd.cs_base - dosplus_sys.cs_base), 
			dos_cmd.cs_len);
		cmdcpy(&dos_cmd, DGROUP, 0, &dosplus_sys, CGROUP, 
			16L * (dos_cmd.ds_base - dosplus_sys.cs_base), 
			dos_cmd.ds_len);
	}
	dump_cmd("BDOS ", &bdos_cmd);
	dump_cmd("XIOS ", &xios_cmd);
	if (dos_cmd.cs_len) dump_cmd("DOS  ", &dos_cmd);
	dump_cmd("CCP  ", &ccp_cmd);

	/* RSP2 is something I've never seen other than zero. I think
 	 * it's intended for networking (in which case the boot file
	 * would be NETPLUS.SYS). */
	printf("RSP2      is at %04x:0000\n", 
			peekw_cmd(&dosplus_sys, DGROUP, 0x26));

	/* Wipe out the in-memory-header bits of CCP */
	for (n = 0; n < 16; n++)
	{
		poke_cmd(&ccp_cmd, DGROUP, n, 0);
	}
	/* Reverse the buffer fixups that DPGEN does */
	unfixup_buffers();
	/* Now start writing the stuff out */
	boo           = save_cmd("bdos.cmd", &bdos_cmd, 0);
	if (!boo) boo = save_cmd("xios.cmd", &xios_cmd, 0);
	if (!boo) boo = save_cmd("ccp.cmd",  &ccp_cmd, 0);

	if (dos_cmd.cs_len && !boo)
	{	
		boo = save_cmd("dos.cmd", &dos_cmd, 0);	
	}	
	if (boo) fprintf(stderr, "%s\n", boo);
	free_cmd(&dosplus_sys); 
	return 0;
}


